# KGCL-schema

This is the schema to the KGCL project.

## Documentation
[Read more here.](https://incatools.github.io/kgcl/)

